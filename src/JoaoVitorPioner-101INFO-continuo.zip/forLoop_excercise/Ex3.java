package forLoop_excercise;

public class Ex3 {

	public static void main(String[] args) {
		// Author: Joao Vitor Souza Pioner | Date: 08/06/2021 14:32

		for (int i = 1; i <= 5000; i++) {
			if (i % 2 == 0) {
				System.out.println(i);
			}
		}
	}

}
